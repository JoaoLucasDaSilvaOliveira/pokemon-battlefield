package org.pokemonbattlefield; // Use o nome do seu pacote raiz

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemonBattlefieldApplication {

    public static void main(String[] args) {
        SpringApplication.run(PokemonBattlefieldApplication.class, args);
    }

}