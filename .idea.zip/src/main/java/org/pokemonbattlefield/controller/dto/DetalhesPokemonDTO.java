package org.pokemonbattlefield.controller.dto;

public record DetalhesPokemonDTO(

        Integer id,
        String nome,
        String tipo

) {
}
