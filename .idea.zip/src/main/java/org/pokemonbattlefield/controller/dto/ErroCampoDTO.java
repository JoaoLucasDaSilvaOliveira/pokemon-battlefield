package org.pokemonbattlefield.controller.dto;

public record ErroCampoDTO(String campo, String erro) {
}
