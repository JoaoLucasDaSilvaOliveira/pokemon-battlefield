package org.pokemonbattlefield.controller.dto.ApiPokemon;

public record PokemonResumoDTO(
        String name,
        String url
) {}