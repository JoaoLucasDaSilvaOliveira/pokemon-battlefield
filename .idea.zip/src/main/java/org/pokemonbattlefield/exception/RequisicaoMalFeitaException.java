package org.pokemonbattlefield.exception;

public class RequisicaoMalFeitaException extends RuntimeException {
    public RequisicaoMalFeitaException(String message) {
        super(message);
    }
}
